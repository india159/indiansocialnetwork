$(document).ready(function() {
        setInterval(function() {
            Ossn.NotificationsCheck()
        }, 5000 * 12);
});