<div class="ossn-comment-attach-photo"><i class="fa fa-smile-o"></i></div>
